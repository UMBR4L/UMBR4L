import "./UserAvatar.scss";

const UserAvatar = () => { 
    return (
        <img src={`../../assets/images/Mohan-muruge.jpg`} alt={"user profile"} />
    );
};

export default UserAvatar;
