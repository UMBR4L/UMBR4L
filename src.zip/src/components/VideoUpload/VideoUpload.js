import React from 'react';
import "./VideoUpload.scss"

function VideoUpload() {
  return (
    <button className="upload-button button">Upload</button>
  );
}

export default VideoUpload;